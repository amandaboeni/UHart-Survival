﻿using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class Registration : MonoBehaviour
{

    public GameObject RegistrationPage;
    public GameObject LoginPage;
    public GameObject regusername;
    public GameObject regpassword;
    public GameObject regemail;
    public GameObject RegError;
    public GameObject RegErrorTwo;
    public GameObject RegErrorThree;
    private string Regusername;
    private string Regpassword;
    private string Regemail;
    private bool Emailconfig;
    private string form;

    // Use this for initialization
    void Start()
    {


    }

    public void RegisterComplete()
    {
        string pathfinder = Application.dataPath + "/StreamingAssets/Registered.txt";
        bool RUN = false;
        bool RPW = false;
        bool REM = false;

        if (Regusername != "")
        {
            if (File.Exists(pathfinder) && pathfinder.Contains(Regusername) == false)
            {
                RUN = true;
            }
            else
            {
                Debug.LogWarning("Choose another username");               //having issues in the code here!!! it wont do the things for username but it works fine for password
            }
        }
        else
        {
            Debug.LogWarning("There's nothing in the Username Field");
            RegError.SetActive(false);
            RegErrorTwo.SetActive(true);
            RegErrorThree.SetActive(false);
        }

        if (Regpassword != "")
        {
            if (File.Exists(pathfinder) && pathfinder.Contains(Regpassword) == false)
            {
                RPW = true;
            }
            else
            {
                Debug.LogWarning("Your password is weak");
                RegError.SetActive(false);
                RegErrorTwo.SetActive(true);
                RegErrorThree.SetActive(false);
            }
        }
        else
        {
            Debug.LogWarning("There's nothing in the Password Field");
            RegError.SetActive(false);
            RegErrorTwo.SetActive(false);
            RegErrorThree.SetActive(true);
        }

        if(Regemail != "")
        {
            if (Regemail.Contains("@") && Regemail.Contains("."))
            {
                REM = true;
            }
            else
            {
                Debug.LogWarning("Email invalid");
                RegError.SetActive(true);
                RegErrorTwo.SetActive(false);
                RegErrorThree.SetActive(false);
            }
        }

        if (REM==true && RUN == true && RPW == true)
        {
            form = (System.DateTime.Now + "  " + Regemail + "\t" + Regusername + "\t" + Regpassword + "\r\n");
            File.AppendAllText(pathfinder, form);
            regusername.GetComponent<InputField>().text = "";
            regpassword.GetComponent<InputField>().text = "";
            print("You did it!!! Registration successful");
            //Put the code in which switches game objects as active or deactive
            RegistrationPage.SetActive(false);
            LoginPage.SetActive(true);
            
            
        }
    }

    // Update is called once per frame
    void Update()
    {
        //Allows user to tab from one input box to the other
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (regemail.GetComponent<InputField>().isFocused)
            {
                regusername.GetComponent<InputField>().Select();
            }

            if (regusername.GetComponent<InputField>().isFocused)
            {
                regpassword.GetComponent<InputField>().Select();
            }
        }
        //if enter key is pressed then it automatically goes to the registration button
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (Regpassword != "")
            {
                RegisterComplete();
            }
        }
        Regusername = regusername.GetComponent<InputField>().text;
        Regpassword = regpassword.GetComponent<InputField>().text;
        Regemail = regemail.GetComponent<InputField>().text;
    }
}
