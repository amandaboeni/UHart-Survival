﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class numPlay : MonoBehaviour {
	public static int playerLimit=4;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	/*void Update () {
		
	}*/
	public void choose1Player(){
		playerLimit=1;
	}
	public void choose2Player(){
		playerLimit=2;
	}
	public void choose3Player(){
		playerLimit=3;
	}
	public void choose4Player(){
		playerLimit=4;
	}
}
