﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class focusSelect : MonoBehaviour {
	public static int player1Focus=1;
	public static int player2Focus=2;
	public static int player3Focus=3;
	public static int player4Focus=4;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	/*void Update () {
		
	}*/
	public void as1(){
		player1Focus=1;
		Debug.Log("Player 1: " + player1Focus);
	}
	public void barney1(){
		player1Focus=2;
	}
	public void hillyer1(){
		player1Focus=3;
	}
	public void hartt1(){
		player1Focus=4;
	}
	public void art1(){
		player1Focus=5;
	}
	public void ceta1(){
		player1Focus=6;
	}
	public void edunur1(){
		player1Focus=7;
	}

	public void as2(){
		player2Focus=1;
	}
	public void barney2(){
		player2Focus=2;
	}
	public void hillyer2(){
		player2Focus=3;
	}
	public void hartt2(){
		player2Focus=4;
	}
	public void art2(){
		player2Focus=5;
	}
	public void ceta2(){
		player2Focus=6;
	}
	public void edunur2(){
		player2Focus=7;
	}

	public void as3(){
		player3Focus=1;
	}
	public void barney3(){
		player3Focus=2;
	}
	public void hillyer3(){
		player3Focus=3;
	}
	public void hartt3(){
		player3Focus=4;
	}
	public void art3(){
		player3Focus=5;
	}
	public void ceta3(){
		player3Focus=6;
	}
	public void edunur3(){
		player3Focus=7;
	}

	public void as4(){
		player4Focus=1;
	}
	public void barney4(){
		player4Focus=2;
	}
	public void hillyer4(){
		player4Focus=3;
	}
	public void hartt4(){
		player4Focus=4;
	}
	public void art4(){
		player4Focus=5;
	}
	public void ceta4(){
		player4Focus=6;
	}
	public void edunur4(){
		player4Focus=7;
	}
}
