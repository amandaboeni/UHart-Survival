﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class closeBadWindow : MonoBehaviour
{
    public static GameObject eventWindowBad;
    
    // Start is called before the first frame update
    public void Start()
    {
        eventWindowBad = GameObject.Find("eventWindowBad");
    }
    public void OnMouseDown()
    {
        eventWindowBad = GameObject.Find("eventWindowBad");
        if(eventWindowBad.activeSelf){
            eventWindowBad.gameObject.SetActive(false);
        }
    }
}
