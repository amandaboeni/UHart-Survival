﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class closeGoodWindow : MonoBehaviour
{
    public static GameObject eventWindowGood;
    
    // Start is called before the first frame update
    public void Start()
    {
        eventWindowGood = GameObject.Find("eventWindowGood");
    }
    public void OnMouseDown()
    {
        eventWindowGood = GameObject.Find("eventWindowGood");
        if(eventWindowGood.activeSelf){
            eventWindowGood.gameObject.SetActive(false);
        }
    }
}
