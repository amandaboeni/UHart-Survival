﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AdjustCamera : MonoBehaviour {
	public Camera camera1;      //cameras switch between players
    public Camera camera2;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	public void OnMouseDown () {
		camera1.enabled=true;
        camera2.enabled=false;
	}
}
