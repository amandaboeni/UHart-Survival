﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Die : MonoBehaviour//, IPointerDownHandler
{
    
    private Sprite[] diceSides;
    private SpriteRenderer rend;
    public static int turn = 1;
    //public static int playerLimit = 3; //Used to determine the number of players in the game.
    private bool coroutineAllowed = true;

    public void Start()
    {
        rend = GetComponent<SpriteRenderer>();
        diceSides = Resources.LoadAll<Sprite>("DiceSides/");
        rend.sprite = diceSides[5];
    }

    public void OnPointerDown()//(PointerEventData eventData)
    {
        
        if(!GameControl.gameOver && coroutineAllowed)
        {
            StartCoroutine("RollTheDice");
        }
    }

    public IEnumerator RollTheDice()
    {
        coroutineAllowed = false;
        int randomDiceSide = 0;
        for(int i = 0; i<=20; i++)
        {
            randomDiceSide = Random.Range(0,6);
            rend.sprite = diceSides[randomDiceSide];
            yield return new WaitForSeconds(0.05f);
        }
        //randomDiceSide=90;
        GameControl.diceSide = randomDiceSide + 1;
        if(turn>numPlay.playerLimit){
            turn=1;
        }
        if (turn == 1)
        {
            //Debug.Log("Player 1: " + Die.turn);
            GameControl.MovePlayer(1);
        } 
        else if(turn == 2)
        {
            //Debug.Log("Player 2: " + Die.turn);
            GameControl.MovePlayer(2);
        }
        else if(turn == 3)
        {
            //Debug.Log("Player 3: " + Die.turn);
            GameControl.MovePlayer(3);
        }
        else if(turn == 4)
        {
            //Debug.Log("Player 4: " + Die.turn);
            GameControl.MovePlayer(4);
        }
        
        /*if(turn>playerLimit){
            turn=1;
        }*/
        turn +=1;
        //if(turn>2){turn = 1;}
        coroutineAllowed = true;
    }
}
