﻿using UnityEngine;
using UnityEngine.UI;
using System.IO;
using System.Linq;

public class Login : MonoBehaviour
{
    public GameObject PlayerSelectPage;
    public GameObject TitleScreen;
    public GameObject LoginPage;
    public GameObject LoginError;
    public GameObject LoginErrorTwo;
    public GameObject Username;
    public GameObject Password;
    private string Loggusername;
    private string Loggpassword;


    // Use this for initialization
    void Start()
    {

    }

    public void LoginComplete()
    {
        string pathfinder = Application.dataPath + "/StreamingAssets/Registered.txt";
        string[] loginLines = File.ReadAllLines(pathfinder);
        bool RUN = false;
        bool RPW = false;
        if (Loggusername != "")
        {
            if (File.Exists(pathfinder) && loginLines.Any(line => line.Contains(Loggusername)))
            {
                RUN = true;
                //passwordLines = File.ReadAllLines(Application.dataPath + "Registered.txt");
            }
            else
            {
                Debug.LogWarning("Username Invalid");
            }
        }
        else
        {
            Debug.LogWarning("There's nothing in the Username Field");
        }

        if (Loggpassword != "")
        {
            if (File.Exists(pathfinder) && loginLines.Any(line => line.Contains(Loggpassword)))
            {
                RPW = true;
            }
            else
            {
                Debug.LogWarning("You've entered an incorrect password.");
                LoginError.SetActive(true);
                LoginErrorTwo.SetActive(false);
            }
        }
        else
        {
            Debug.LogWarning("There's nothing in the Password Field");
            LoginErrorTwo.SetActive(true);
            LoginError.SetActive(false);
        }

        if (RUN == true && RPW == true)
        {
            Username.GetComponent<InputField>().text = "";
            Password.GetComponent<InputField>().text = "";
            print("Login Successful......Respect +");
            LoginPage.SetActive(false);
            PlayerSelectPage.SetActive(true);
            LoginError.SetActive(false);
        }
    }

    public void MainPage()
    {
        LoginPage.SetActive(false);
        TitleScreen.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {

        //Allows user to tab from one input box to the other
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            if (Username.GetComponent<InputField>().isFocused)
            {
                Password.GetComponent<InputField>().Select();
            }
        }

        //if enter key is pressed then it automatically goes to the registration button
        if (Input.GetKeyDown(KeyCode.Return))
        {
            if (Loggpassword != "")
            {
                LoginComplete();
            }
        }

        Loggusername = Username.GetComponent<InputField>().text;
        Loggpassword = Password.GetComponent<InputField>().text;
    }
}
