﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class closeGCWindow : MonoBehaviour
{
    public static GameObject eventWindowGC;
    
    // Start is called before the first frame update
    public void Start()
    {
        eventWindowGC = GameObject.Find("eventWindowGC");
    }
    public void OnMouseDown()
    {
        eventWindowGC = GameObject.Find("eventWindowGC");
        if(eventWindowGC.activeSelf){
            eventWindowGC.gameObject.SetActive(false);
        }
    }
}
