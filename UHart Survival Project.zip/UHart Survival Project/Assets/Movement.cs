﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Movement : MonoBehaviour
{
    public static GameObject Player1TurnText, Player2TurnText, Player3TurnText, Player4TurnText;
    public Transform[] waypoints;

    [SerializeField]
    private float speed = 1f;

    [HideInInspector]
    public int waypointIndex = 0;

    public bool moveAllowed = false;

    private void Start()
    {
        transform.position = waypoints[waypointIndex].transform.position;
        //Player1TurnText = GameObject.Find("Player1TurnText");   
        //Player2TurnText = GameObject.Find("Player2TurnText");

    }

    private void Update()
    {
        Player1TurnText = GameObject.Find("Player1TurnText");   
        Player2TurnText = GameObject.Find("Player2TurnText");
        Player3TurnText = GameObject.Find("Player3TurnText");
        Player4TurnText = GameObject.Find("Player4TurnText");
        if (moveAllowed){
            Move();
        }
    }

    private void Move()
    {
        if (waypointIndex <= waypoints.Length-1)
        {
            int moveValue = GameControl.diceSide;
            if(Die.turn==2){
                //Debug.Log("Player 1: " + Die.turn);
                Player1TurnText.GetComponent<Text>().text = "Rolled " + moveValue.ToString();
            }
            else if(Die.turn==3){
                //Debug.Log("Player 2: " + Die.turn);
                Player2TurnText.GetComponent<Text>().text = "Rolled " + moveValue.ToString();
            }
            else if(Die.turn==4){
                //Debug.Log("Player 3: " + Die.turn);
                Player3TurnText.GetComponent<Text>().text = "Rolled " + moveValue.ToString();
            }
            else if(Die.turn==1){
                //Debug.Log("Player 4: " + Die.turn);
                Player4TurnText.GetComponent<Text>().text = "Rolled " + moveValue.ToString();
            }
            transform.position = Vector2.MoveTowards(transform.position, waypoints[waypointIndex].transform.position, speed*Time.deltaTime);
            if(transform.position == waypoints[waypointIndex].transform.position)
            {
                waypointIndex+=1;
            }
        }
    }
}
