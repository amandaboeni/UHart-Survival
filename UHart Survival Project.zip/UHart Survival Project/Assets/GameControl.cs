﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameControl : MonoBehaviour
{
    /*private static GameObject winnerText, winnerText2, Player1Turn, Player2Turn, Player1TurnText, Player2TurnText;
    private static GameObject eventWindowGood, eventWindowBad, eventTextGood, eventTextBad, eventWindowGC, eventTextGC, resultsScreen;
    private static GameObject Academics1,Academics2,Finance1,Finance2,Happiness1,Happiness2,Stress1,Stress2;*/
    private static GameObject Player1Turn, Player1TurnText, Academics1, Finance1, Happiness1, Stress1; //UI elements
    private static GameObject Player2Turn, Player2TurnText, Academics2, Finance2, Happiness2, Stress2;
    private static GameObject Player3Turn, Player3TurnText, Academics3, Finance3, Happiness3, Stress3;
    private static GameObject Player4Turn, Player4TurnText, Academics4, Finance4, Happiness4, Stress4;
    private static GameObject winnerText, winnerText2, resultsScreen;
    private static GameObject eventWindowGood, eventTextGood, eventWindowBad, eventTextBad, eventWindowGC, eventTextGC;
    private static GameObject player1, player2, player3, player4;
    private static GameObject player2Status, player3Status, player4Status;
    public Camera camera1, camera2, camera3, camera4;      //cameras switch between players
    public Sprite sprite2, sprite3, sprite4, noSprite;

    

    public static int diceSide=0;
    public static int player1Start = 0;     //track current position of players
    public static int player2Start = 0;
    public static int player3Start = 0;
    public static int player4Start = 0;

    public static int player1Aca = 50;     //integers for player stats
    public static int player1Fin = 50;
    public static int player1Hap = 50;
    public static int player1Ste = 50;
    public static int player2Aca = 50;
    public static int player2Fin = 50;
    public static int player2Hap = 50;
    public static int player2Ste = 50;
    public static int player3Aca = 50;
    public static int player3Fin = 50;
    public static int player3Hap = 50;
    public static int player3Ste = 50;
    public static int player4Aca = 50;
    public static int player4Fin = 50;
    public static int player4Hap = 50;
    public static int player4Ste = 50;

    //These boolean variables display messages based on how many times the player has moved around the board.
    public static bool p1y1, p1y2, p1y3, p1y4 = false;
    public static bool p2y1, p2y2, p2y3, p2y4 = false;
    public static bool p3y1, p3y2, p3y3, p3y4 = false;
    public static bool p4y1, p4y2, p4y3, p4y4 = false;

    public static bool gameOver = false; //checks if game is over

    void Start()
    {
        Player1Turn = GameObject.Find("Player1Turn");   
        Player2Turn = GameObject.Find("Player2Turn"); 
        Player3Turn = GameObject.Find("Player3Turn");
        Player4Turn = GameObject.Find("Player4Turn");
        Player1TurnText = GameObject.Find("Player1TurnText");   
        Player2TurnText = GameObject.Find("Player2TurnText");
        Player3TurnText = GameObject.Find("Player3TurnText");
        Player4TurnText = GameObject.Find("Player4TurnText");

        player2Status = GameObject.Find("Player2Status");
        player3Status = GameObject.Find("Player3Status");
        player4Status = GameObject.Find("Player4Status");
        
        eventWindowGood = GameObject.Find("eventWindowGood");
        eventTextGood = GameObject.Find("eventTextGood");
        eventWindowBad = GameObject.Find("eventWindowBad");
        eventTextBad = GameObject.Find("eventTextBad");
        eventWindowGC = GameObject.Find("eventWindowGC");
        eventTextGC = GameObject.Find("eventTextGC");
        winnerText = GameObject.Find("winnerText");
        winnerText2 = GameObject.Find("winnerText2");
        resultsScreen = GameObject.Find("resultsScreen");

        player1 = GameObject.Find("player1");
        player2 = GameObject.Find("player2");
        player3 = GameObject.Find("player3");
        player4 = GameObject.Find("player4");

        Academics1 = GameObject.Find("Academics1");     //player 1 stat text fields
        Finance1 = GameObject.Find("Finance1");
        Happiness1 = GameObject.Find("Happiness1");
        Stress1 = GameObject.Find("Stress1");
        Academics2 = GameObject.Find("Academics2");     //player 2 stat text fields
        Finance2 = GameObject.Find("Finance2");
        Happiness2 = GameObject.Find("Happiness2");
        Stress2 = GameObject.Find("Stress2");
        Academics3 = GameObject.Find("Academics3");     //player 3 stat text fields
        Finance3 = GameObject.Find("Finance3");
        Happiness3 = GameObject.Find("Happiness3");
        Stress3 = GameObject.Find("Stress3");
        Academics4 = GameObject.Find("Academics4");     //player 4 stat text fields
        Finance4 = GameObject.Find("Finance4");
        Happiness4 = GameObject.Find("Happiness4");
        Stress4 = GameObject.Find("Stress4");

        player1.GetComponent<Movement>().moveAllowed = false;
        player2.GetComponent<Movement>().moveAllowed = false;
        player3.GetComponent<Movement>().moveAllowed = false;
        player4.GetComponent<Movement>().moveAllowed = false;

        Player1TurnText.GetComponent<Text>().text = "Player 1";
        Player2TurnText.GetComponent<Text>().text = "Player 2";
        Player3TurnText.GetComponent<Text>().text = "Player 3";
        Player4TurnText.GetComponent<Text>().text = "Player 4";

        //Player 1 goes first
        Player1Turn.gameObject.SetActive(true);
        Player2Turn.gameObject.SetActive(false);
        Player3Turn.gameObject.SetActive(false);
        Player4Turn.gameObject.SetActive(false);
        
        resultsScreen.gameObject.SetActive(false);
        eventWindowGood.gameObject.SetActive(false);
        eventWindowBad.gameObject.SetActive(false);
        eventWindowGC.gameObject.SetActive(false);

        //Start with player 1 camera
        camera1.enabled=true;
        camera2.enabled=false;
        camera3.enabled=false;
        camera4.enabled=false;

        
    }

    // Update is called once per frame
    void Update()
    {
        //Remove player tokens and their status windows based on player # limit
        if(numPlay.playerLimit==4){
            //player4.gameObject.SetActive(false);
            player2.GetComponent<SpriteRenderer>().sprite = sprite2;
            player3.GetComponent<SpriteRenderer>().sprite = sprite3;
            player4.GetComponent<SpriteRenderer>().sprite = sprite4;
            player2Status.gameObject.SetActive(true);
            player3Status.gameObject.SetActive(true);
            player4Status.gameObject.SetActive(true);
        }
        if(numPlay.playerLimit==3){
            //player3.gameObject.SetActive(false);
            player2.GetComponent<SpriteRenderer>().sprite = sprite2;
            player3.GetComponent<SpriteRenderer>().sprite = sprite3;
            player4.GetComponent<SpriteRenderer>().sprite = noSprite;
            player2Status.gameObject.SetActive(true);
            player3Status.gameObject.SetActive(true);
            player4Status.gameObject.SetActive(false);
        }
        if(numPlay.playerLimit==2){
            player2.GetComponent<SpriteRenderer>().sprite = sprite2;
            player3.GetComponent<SpriteRenderer>().sprite = noSprite;
            player4.GetComponent<SpriteRenderer>().sprite = noSprite;
            player2Status.gameObject.SetActive(true);
            player3Status.gameObject.SetActive(false);
            player4Status.gameObject.SetActive(false);
        }
        if(numPlay.playerLimit==1){
            player2.GetComponent<SpriteRenderer>().sprite = noSprite;
            player3.GetComponent<SpriteRenderer>().sprite = noSprite;
            player4.GetComponent<SpriteRenderer>().sprite = noSprite;
            player2Status.gameObject.SetActive(false);
            player3Status.gameObject.SetActive(false);
            player4Status.gameObject.SetActive(false);
        }
    //PLAYER 1 MOVEMENT
        if(player1.GetComponent<Movement>().waypointIndex > player1Start + diceSide) //Player 1 Movement
        {
            player1Start = player1.GetComponent<Movement>().waypointIndex - 1;
            player1.GetComponent<Movement>().moveAllowed = false; //Once player 1 stops moving, player 1 can not move
            //Increase stats for blue spaces
            if(player1Start>=22&&p1y1==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 1 has completed their first year.\nHappiness + 30";
                player1Hap+=30;
                p1y1=true;
                Happiness1.GetComponent<Text>().text = player1Hap.ToString();
            }
            else if(player1Start>=44&&p1y2==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 1 has completed their second year.\nHappiness + 30";
                player1Hap+=30;
                p1y2=true;
                Happiness1.GetComponent<Text>().text = player1Hap.ToString();
            }
            else if(player1Start>=66&&p1y3==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 1 has completed their third year.\nHappiness + 30";
                player1Hap+=30;
                p1y3=true;
                Happiness1.GetComponent<Text>().text = player1Hap.ToString();
            }
            else if(player1Start==1||player1Start==3||player1Start==7||player1Start==8||player1Start==12||player1Start==15||player1Start==16||player1Start==19||player1Start==20||player1Start==21
            ||player1Start==1+22||player1Start==3+22||player1Start==7+22||player1Start==8+22||player1Start==12+22||player1Start==15+22||player1Start==16+22||player1Start==19+22||player1Start==20+22||player1Start==21+22
            ||player1Start==1+44||player1Start==3+44||player1Start==7+44||player1Start==8+44||player1Start==12+44||player1Start==15+44||player1Start==16+44||player1Start==19+44||player1Start==20+44||player1Start==21+44
            ||player1Start==1+66||player1Start==3+66||player1Start==7+66||player1Start==8+66||player1Start==12+66||player1Start==15+66||player1Start==16+66||player1Start==19+66||player1Start==20+66||player1Start==21+66
            ){
                goodEvent1();
            }
            else if(player1Start==2||player1Start==4||player1Start==5||player1Start==6||player1Start==9||player1Start==10||player1Start==13||player1Start==14||player1Start==17||player1Start==18
            ||player1Start==2+22||player1Start==4+22||player1Start==5+22||player1Start==6+22||player1Start==9+22||player1Start==10+22||player1Start==13+22||player1Start==14+22||player1Start==17+22||player1Start==18+22
            ||player1Start==2+44||player1Start==4+44||player1Start==5+44||player1Start==6+44||player1Start==9+44||player1Start==10+44||player1Start==13+44||player1Start==14+44||player1Start==17+44||player1Start==18+44
            ||player1Start==2+66||player1Start==4+66||player1Start==5+66||player1Start==6+66||player1Start==9+66||player1Start==10+66||player1Start==13+66||player1Start==14+66||player1Start==17+66||player1Start==18+66
            ){
                badEvent1();
            } //decrease stats for red spaces
            else if(player1Start==11||player1Start==11+22||player1Start==11+44||player1Start==11+66){
                gcEvent1();
            }
            wait();
            if(numPlay.playerLimit==1){
                //Stay as player 1
            }
            else{
                camera2.enabled = true; //Camera switches to 2
                camera1.enabled = false;
                Player1Turn.gameObject.SetActive(false);
                Player2Turn.gameObject.SetActive(true);
            }
            Player1TurnText.GetComponent<Text>().text = "Player 1";
            Player2TurnText.GetComponent<Text>().text = "Player 2";
            Player3TurnText.GetComponent<Text>().text = "Player 3";
            Player4TurnText.GetComponent<Text>().text = "Player 4";
        }

    //PLAYER 2 MOVEMENT
        if(player2.GetComponent<Movement>().waypointIndex > player2Start + diceSide)
        {
            //Increase stats for blue spaces
            player2Start = player2.GetComponent<Movement>().waypointIndex - 1;
            player2.GetComponent<Movement>().moveAllowed = false;

            if(player2Start>=22&&p2y1==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 2 has completed their first year.\nHappiness + 30";
                player2Hap+=30;
                p2y1=true;
                Happiness2.GetComponent<Text>().text = player2Hap.ToString();
            }
            else if(player2Start>=44&&p2y2==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 2 has completed their second year.\nHappiness + 30";
                player2Hap+=30;
                p2y2=true;
                Happiness2.GetComponent<Text>().text = player2Hap.ToString();
            }
            else if(player2Start>=66&&p2y3==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 2 has completed their third year.\nHappiness + 30";
                player2Hap+=30;
                p2y3=true;
                Happiness2.GetComponent<Text>().text = player2Hap.ToString();
            }
            else if(player2Start==1||player2Start==3||player2Start==7||player2Start==8||player2Start==12||player2Start==15||player2Start==16||player2Start==19||player2Start==20||player2Start==21
            ||player2Start==1+22||player2Start==3+22||player2Start==7+22||player2Start==8+22||player2Start==12+22||player2Start==15+22||player2Start==16+22||player2Start==19+22||player2Start==20+22||player2Start==21+22
            ||player2Start==1+44||player2Start==3+44||player2Start==7+44||player2Start==8+44||player2Start==12+44||player2Start==15+44||player2Start==16+44||player2Start==19+44||player2Start==20+44||player2Start==21+44
            ||player2Start==1+66||player2Start==3+66||player2Start==7+66||player2Start==8+66||player2Start==12+66||player2Start==15+66||player2Start==16+66||player2Start==19+66||player2Start==20+66||player2Start==21+66
            ){
                goodEvent2();
            }
            else if(player2Start==2||player2Start==4||player2Start==5||player2Start==6||player2Start==9||player2Start==10||player2Start==13||player2Start==14||player2Start==17||player2Start==18
            ||player2Start==2+22||player2Start==4+22||player2Start==5+22||player2Start==6+22||player2Start==9+22||player2Start==10+22||player2Start==13+22||player2Start==14+22||player2Start==17+22||player2Start==18+22
            ||player2Start==2+44||player2Start==4+44||player2Start==5+44||player2Start==6+44||player2Start==9+44||player2Start==10+44||player2Start==13+44||player2Start==14+44||player2Start==17+44||player2Start==18+44
            ||player2Start==2+66||player2Start==4+66||player2Start==5+66||player2Start==6+66||player2Start==9+66||player2Start==10+66||player2Start==13+66||player2Start==14+66||player2Start==17+66||player2Start==18+66
            ){
                badEvent2();
            } //decrease stats for red spaces
            else if(player2Start==11||player2Start==11+22||player2Start==11+44||player2Start==11+66){
                gcEvent2();
            }
            wait();
            if(numPlay.playerLimit==2){
                camera1.enabled = true; //if 2 players, go to player 1
                camera2.enabled = false;
                Player2Turn.gameObject.SetActive(false);
                Player1Turn.gameObject.SetActive(true);
            }
            else{
                camera3.enabled = true;
                camera2.enabled = false;
                Player2Turn.gameObject.SetActive(false);
                Player3Turn.gameObject.SetActive(true);
            }
            
            Player1TurnText.GetComponent<Text>().text = "Player 1";
            Player2TurnText.GetComponent<Text>().text = "Player 2";
            Player3TurnText.GetComponent<Text>().text = "Player 3";
            Player4TurnText.GetComponent<Text>().text = "Player 4";
        }

    //PLAYER 3 MOVEMENT
        if(player3.GetComponent<Movement>().waypointIndex > player3Start + diceSide)
        {
            //Increase stats for blue spaces
            player3Start = player3.GetComponent<Movement>().waypointIndex - 1;
            player3.GetComponent<Movement>().moveAllowed = false;
            
            if(player3Start>=22&&p3y1==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 3 has completed their first year.\nHappiness + 30";
                player3Hap+=30;
                p3y1=true;
                Happiness3.GetComponent<Text>().text = player3Hap.ToString();
            }
            else if(player3Start>=44&&p3y2==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 3 has completed their second year.\nHappiness + 30";
                player3Hap+=30;
                p3y2=true;
                Happiness3.GetComponent<Text>().text = player3Hap.ToString();

            }
            else if(player3Start>=66&&p3y3==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 3 has completed their third year.\nHappiness + 30";
                player3Hap+=30;
                p3y3=true;
                Happiness3.GetComponent<Text>().text = player3Hap.ToString();
            }
            else if(player3Start==1||player3Start==3||player3Start==7||player3Start==8||player3Start==12||player3Start==15||player3Start==16||player3Start==19||player3Start==20||player3Start==21
            ||player3Start==1+22||player3Start==3+22||player3Start==7+22||player3Start==8+22||player3Start==12+22||player3Start==15+22||player3Start==16+22||player3Start==19+22||player3Start==20+22||player3Start==21+22
            ||player3Start==1+44||player3Start==3+44||player3Start==7+44||player3Start==8+44||player3Start==12+44||player3Start==15+44||player3Start==16+44||player3Start==19+44||player3Start==20+44||player3Start==21+44
            ||player3Start==1+66||player3Start==3+66||player3Start==7+66||player3Start==8+66||player3Start==12+66||player3Start==15+66||player3Start==16+66||player3Start==19+66||player3Start==20+66||player3Start==21+66
            ){
                goodEvent3();
            }
            else if(player3Start==2||player3Start==4||player3Start==5||player3Start==6||player3Start==9||player3Start==10||player3Start==13||player3Start==14||player3Start==17||player3Start==18
            ||player3Start==2+22||player3Start==4+22||player3Start==5+22||player3Start==6+22||player3Start==9+22||player3Start==10+22||player3Start==13+22||player3Start==14+22||player3Start==17+22||player3Start==18+22
            ||player3Start==2+44||player3Start==4+44||player3Start==5+44||player3Start==6+44||player3Start==9+44||player3Start==10+44||player3Start==13+44||player3Start==14+44||player3Start==17+44||player3Start==18+44
            ||player3Start==2+66||player3Start==4+66||player3Start==5+66||player3Start==6+66||player3Start==9+66||player3Start==10+66||player3Start==13+66||player3Start==14+66||player3Start==17+66||player3Start==18+66
            ){
                badEvent3();
            } //decrease stats for red spaces
            else if(player3Start==11||player3Start==11+22||player3Start==11+44||player3Start==11+66){
                gcEvent3();
            }
            wait();
            if(numPlay.playerLimit==3){
                camera1.enabled = true; //if 3 players, go to player 1
                camera3.enabled = false;
                Player3Turn.gameObject.SetActive(false);
                Player1Turn.gameObject.SetActive(true);
            }
            else{
                camera4.enabled = true;
                camera3.enabled = false;
                Player3Turn.gameObject.SetActive(false);
                Player4Turn.gameObject.SetActive(true);
            }
            
            Player1TurnText.GetComponent<Text>().text = "Player 1";
            Player2TurnText.GetComponent<Text>().text = "Player 2";
            Player3TurnText.GetComponent<Text>().text = "Player 3";
            Player4TurnText.GetComponent<Text>().text = "Player 4";
        }

    //PLAYER 4 MOVEMENT
        if(player4.GetComponent<Movement>().waypointIndex > player4Start + diceSide)
        {
            //Increase stats for blue spaces
            player4Start = player4.GetComponent<Movement>().waypointIndex - 1;
            player4.GetComponent<Movement>().moveAllowed = false;
            
            if(player4Start>=22&&p4y1==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 4 has completed their first year.\nHappiness + 30";
                player4Hap+=30;
                p4y1=true;
                Happiness4.GetComponent<Text>().text = player4Hap.ToString();
            }
            else if(player4Start>=44&&p4y2==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 4 has completed their second year.\nHappiness + 30";
                player4Hap+=30;
                p4y2=true;
                Happiness4.GetComponent<Text>().text = player4Hap.ToString();
            }
            else if(player4Start>=66&&p4y3==false){
                eventWindowGood.gameObject.SetActive(true);
                eventTextGood.GetComponent<Text>().text = "Player 4 has completed their third year.\nHappiness + 30";
                player4Hap+=30;
                p4y3=true;
                Happiness4.GetComponent<Text>().text = player4Hap.ToString();
            }
            else if(player4Start==1||player4Start==3||player4Start==7||player4Start==8||player4Start==12||player4Start==15||player4Start==16||player4Start==19||player4Start==20||player4Start==21
            ||player4Start==1+22||player4Start==3+22||player4Start==7+22||player4Start==8+22||player4Start==12+22||player4Start==15+22||player4Start==16+22||player4Start==19+22||player4Start==20+22||player4Start==21+22
            ||player4Start==1+44||player4Start==3+44||player4Start==7+44||player4Start==8+44||player4Start==12+44||player4Start==15+44||player4Start==16+44||player4Start==19+44||player4Start==20+44||player4Start==21+44
            ||player4Start==1+66||player4Start==3+66||player4Start==7+66||player4Start==8+66||player4Start==12+66||player4Start==15+66||player4Start==16+66||player4Start==19+66||player4Start==20+66||player4Start==21+66
            ){
                goodEvent4();
            }
            else if(player4Start==2||player4Start==4||player4Start==5||player4Start==6||player4Start==9||player4Start==10||player4Start==13||player4Start==14||player4Start==17||player4Start==18
            ||player4Start==2+22||player4Start==4+22||player4Start==5+22||player4Start==6+22||player4Start==9+22||player4Start==10+22||player4Start==13+22||player4Start==14+22||player4Start==17+22||player4Start==18+22
            ||player4Start==2+44||player4Start==4+44||player4Start==5+44||player4Start==6+44||player4Start==9+44||player4Start==10+44||player4Start==13+44||player4Start==14+44||player4Start==17+44||player4Start==18+44
            ||player4Start==2+66||player4Start==4+66||player4Start==5+66||player4Start==6+66||player4Start==9+66||player4Start==10+66||player4Start==13+66||player4Start==14+66||player4Start==17+66||player4Start==18+66
            ){
                badEvent4();
            } //decrease stats for red spaces
            else if(player4Start==11||player4Start==11+22||player4Start==11+44||player4Start==11+66){
                gcEvent4();
            }
            wait();
            
            camera1.enabled = true;
            camera4.enabled = false;
            Player4Turn.gameObject.SetActive(false);
            Player1Turn.gameObject.SetActive(true);
            
            Player1TurnText.GetComponent<Text>().text = "Player 1";
            Player2TurnText.GetComponent<Text>().text = "Player 2";
            Player3TurnText.GetComponent<Text>().text = "Player 3";
            Player4TurnText.GetComponent<Text>().text = "Player 4";
        }

    //CHECK FOR GAME OVER
        if(player1.GetComponent<Movement>().waypointIndex == player1.GetComponent<Movement>().waypoints.Length)
        {
            if(p1y4==false){    //winning player receives a 50 point bonus
                player1Hap+=50; //if statement and boolean are here to make sure the bonus is applied only once
                p1y4=true;
            }
            gameOver = true;
            Player1Turn.gameObject.SetActive(false);
        }
        else if(player2.GetComponent<Movement>().waypointIndex == player2.GetComponent<Movement>().waypoints.Length)
        {
            if(p2y4==false){    //winning player receives a 50 point bonus
                player2Hap+=50; //if statement and boolean are here to make sure the bonus is applied only once
                p2y4=true;
            }
            gameOver = true;
            Player1Turn.gameObject.SetActive(false);
            Player2Turn.gameObject.SetActive(false);
            
        }
        else if(player3.GetComponent<Movement>().waypointIndex == player3.GetComponent<Movement>().waypoints.Length)
        {
            if(p3y4==false){    //winning player receives a 50 point bonus
                player3Hap+=50; //if statement and boolean are here to make sure the bonus is applied only once
                p3y4=true;
            }
            gameOver = true;
            Player1Turn.gameObject.SetActive(false);
            Player2Turn.gameObject.SetActive(false);
            Player3Turn.gameObject.SetActive(false);
        }
        else if(player4.GetComponent<Movement>().waypointIndex == player4.GetComponent<Movement>().waypoints.Length)
        {
            if(p4y4==false){    //winning player receives a 50 point bonus
                player4Hap+=50; //if statement and boolean are here to make sure the bonus is applied only once
                p4y4=true;
            }
            gameOver = true;
            Player1Turn.gameObject.SetActive(false);
            Player2Turn.gameObject.SetActive(false);
            Player3Turn.gameObject.SetActive(false);
            Player4Turn.gameObject.SetActive(false);
        }

    //IF GAME OVER TRUE, USE RESULTS SCREEN
        if(gameOver==true){
            int score1=player1Aca+player1Fin+player1Hap-player1Ste;
            int score2=player2Aca+player2Fin+player2Hap-player2Ste;
            int score3=player3Aca+player3Fin+player3Hap-player3Ste;
            int score4=player4Aca+player4Fin+player4Hap-player4Ste;
            if(numPlay.playerLimit==1) //1 player results screen
            {
                if(score1>=score2){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Final Score:";
                    winnerText2.GetComponent<Text>().text = ""+score1;
                }
            }
            if(numPlay.playerLimit==2) //2 player results screen
            {
                if(score1>=score2){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 1";
                }
                else if(score2>=score1){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 2";
                }
            }
            if(numPlay.playerLimit==3) //3 player results screen
            {
                if(score1>=score2&&score1>=score3){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 1";
                }
                else if(score2>=score1&&score2>=score3){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 2";
                }
                else if(score3>=score1&&score3>=score2){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 3";
                }
            }
            if(numPlay.playerLimit==4) //4 player results screen
            {
                if(score1>=score2&&score1>=score3&&score1>=score4){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3+"\nPlayer 4 Score: "+score4;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 1";
                }
                else if(score2>=score1&&score2>=score3&&score2>=score4){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3+"\nPlayer 4 Score: "+score4;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 2";
                }
                else if(score3>=score1&&score3>=score2&&score3>=score4){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3+"\nPlayer 4 Score: "+score4;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 3";
                }
                else if(score4>=score1&&score4>=score2&&score4>=score3){
                    resultsScreen.gameObject.SetActive(true);
                    winnerText.GetComponent<Text>().text = "Player 1 Score: "+score1+"\nPlayer 2 Score: "+score2+"\nPlayer 3 Score: "+score3+"\nPlayer 4 Score: "+score4;
                    winnerText2.GetComponent<Text>().text = "WINNER: PLAYER 4";
                }
            }
        }

    }

    static void goodEvent1(){   //blue space event for player 1
        int eventNumber = Random.Range(1, 22);
        //aca
        if (eventNumber==1){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 completed a homework assignment.\nAcademics + 8";
            player1Aca+=8;
        }
        if (eventNumber == 2)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 studied for a test.\nAcademics + 10";
            player1Aca += 10;
        }
        if (eventNumber == 3)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 did an extra credit assignment.\nAcademics + 6";
            player1Aca += 6;
        }
        if (eventNumber == 4)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 got the project they were stressed about done quicker then they hoped.\nAcademics + 10\nHappiness + 10";
            player1Aca += 10;
            player1Hap += 10;
        }
        if (eventNumber == 5)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 nailed their presentation.\nAcademics + 6\nStress - 10";
            player1Aca += 6;
            player1Ste -= 10;
        }
        //fin
        if (eventNumber == 6)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1's paycheck came in.\nFinances + 18";
            player1Fin += 18;
        }
        if (eventNumber == 7)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 won a bet.\nFinances + 10%";
            player1Fin = (int)(1.1* player1Fin);
        }
        if (eventNumber == 8)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 found a PDF of their textbook online.\nFinances + 14";
            player1Fin += 14;
        }
        if (eventNumber == 9)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 had a friend swipe them into commons.\nFinances + 10\nHappiness + 12";
            player1Fin += 10;
            player1Hap += 12;
        }
        if (eventNumber == 10)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 found a dollar on the ground.\nFinances + 4\nHappiness + 10";
            player1Fin += 4;
            player1Hap += 10;
        }
        //happy
        if (eventNumber==11){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 is well rested after a good nap.\nHappiness + 14";
            player1Hap+=14;
        }
        if (eventNumber == 12)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 had a good meal at commons.\nHappiness + 10\nStress - 6";
            player1Hap += 10;
            player1Ste -= 6;
        }
        if (eventNumber == 13)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1's favorite TV show got another season.\nHappiness + 16";
            player1Hap += 16;
        }
        if (eventNumber == 14)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 took the break from studying and watched a movie with friends.\nHappiness + 10\nStress - 10";
            player1Hap += 10;
            player1Ste -= 10;
        }
        if (eventNumber == 15)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 went out drinking with friends.\nHappiness + 20";
            player1Hap += 20;
        }
        //stress
        if (eventNumber==16){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1's test was postponed.\nStress - 18";
            player1Ste-=18;
        }
        if (eventNumber == 17)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 started practicing yoga.\nStress - 10";
            player1Ste -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1's date went very well!.\nStress - 8\nHappiness + 10";
            player1Ste -= 8;
            player1Hap += 10;
        }
        if (eventNumber == 19)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1 went home for the weekend.\nStress - 20";
            player1Ste -= 20;
        }
        if (eventNumber == 20)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 1's all-nighter paid off with good grades.\nStress - 10\nAcademics + 10";
            player1Ste -= 10;
            player1Aca += 10;
        }
        //focus
        if (eventNumber==21)
	    {
            switch (focusSelect.player1Focus)
            {
                case 1:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1 got a position as a lab instructor.\nAcademics, Finance, and Happiness + 20";
			        player1Aca += 20;
			        player1Fin += 20;
			        player1Hap += 20;
                    break;
                case 2:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1 networked with local business owners and has a summer internship.\nFin + 60";
                    player1Fin += 60;
                    break;
                case 3:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1 had a paper published in an academic journal.\nHappiness + 30\nFinance + 30";
                    player1Fin += 30;
			        player1Hap += 30;
                    break;
                case 4:
			        eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1 nailed their performance and got admited to a summer program in Switzerland.\nHappiness + 60";
			        player1Hap += 60;
                    break;
                case 5:
			        eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1 managed to sell their art.\nHappiness + 20\nFinance + 40";
                    player1Hap += 20;
                    player1Fin += 40;
                    break;
                case 6:
			        eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1 had the best presentation at CETA day.\nAcademics + 50\nHappiness + 10";
                    player1Aca += 50;
                    player1Hap += 10;
                    break;
                case 7:
			        eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 1's student teaching position turned in to a job.\nFinance + 60";
                    player1Fin += 60;
                    break;
            }
        }
        //Stat limits
        if(player1Ste>=100){
            player1Ste=100;
        }
        if(player1Ste<=0){
            player1Ste=0;
        }
        if(player1Aca>=100){
            player1Aca=100;
        }
        if(player1Aca<=0){
            player1Aca=0;
        }
        Academics1.GetComponent<Text>().text = player1Aca.ToString();
        Finance1.GetComponent<Text>().text = player1Fin.ToString();
        Happiness1.GetComponent<Text>().text = player1Hap.ToString();
        Stress1.GetComponent<Text>().text = player1Ste.ToString();
    }

    static void goodEvent2(){   //blue space event for player 2
        int eventNumber = Random.Range(1, 22);
        //aca
        if (eventNumber==1){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 completed a homework assignment.\nAcademics + 8";
            player2Aca+=8;
        }
        if (eventNumber == 2)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 studied for a test.\nAcademics + 10";
            player2Aca += 10;
        }
        if (eventNumber == 3)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 did an extra credit assignment.\nAcademics + 6";
            player2Aca += 6;
        }
        if (eventNumber == 4)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 got the project they were stressed about done quicker then they hoped.\nAcademics + 10\nHappiness + 10";
            player2Aca += 10;
            player2Hap += 10;
        }
        if (eventNumber == 5)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 nailed their presentation.\nAcademics + 6\nStress - 10";
            player2Aca += 6;
            player2Ste -= 10;
        }
        //fin
        if (eventNumber == 6)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2's paycheck came in.\nFinances + 18";
            player2Fin += 18;
        }
        if (eventNumber == 7)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 won a bet.\nFinances + 10%";
            player2Fin = (int)(1.1* player2Fin);
        }
        if (eventNumber == 8)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 found a PDF of their textbook online.\nFinances + 14";
            player2Fin += 14;
        }
        if (eventNumber == 9)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 had a friend swipe them into commons.\nFinances + 10\nHappiness + 12";
            player2Fin += 10;
            player2Hap += 12;
        }
        if (eventNumber == 10)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 found a dollar on the ground.\nFinances + 4\nHappiness + 10";
            player2Fin += 4;
            player2Hap += 10;
        }
        //happy
        if (eventNumber==11){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 is well rested after a good nap.\nHappiness + 14";
            player2Hap+=14;
        }
        if (eventNumber == 12)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 had a good meal at commons.\nHappiness + 10\nStress - 6";
            player2Hap += 10;
            player2Ste -= 6;
        }
        if (eventNumber == 13)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2's favorite TV show got another season.\nHappiness + 16";
            player2Hap += 16;
        }
        if (eventNumber == 14)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 took the break from studying and watched a movie with friends.\nHappiness + 10\nStress - 10";
            player2Hap += 10;
            player2Ste -= 10;
        }
        if (eventNumber == 15)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 went out drinking with friends.\nHappiness + 20";
            player2Hap += 20;
        }
        //stress
        if (eventNumber==16){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2's test was postponed.\nStress - 18";
            player2Ste-=18;
        }
        if (eventNumber == 17)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 started practicing yoga.\nStress - 10";
            player2Ste -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2's date went very well!.\nStress - 8\nHappiness + 10";
            player2Ste -= 8;
            player2Hap += 10;
        }
        if (eventNumber == 19)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2 went home for the weekend.\nStress - 20";
            player2Ste -= 20;
        }
        if (eventNumber == 20)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 2's all-nighter paid off with good grades.\nStress - 10\nAcademics + 10";
            player2Ste -= 10;
            player2Aca += 10;
        }
        //focus
        if (eventNumber==21)
        {
            switch (focusSelect.player2Focus)
            {
                case 1:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2 got a position as a lab instructor.\nAcademics, Finance, and Happiness + 20";
                    player2Aca += 20;
                    player2Fin += 20;
                    player2Hap += 20;
                    break;
                case 2:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2 networked with local business owners and has a summer internship.\nFin + 60";
                    player2Fin += 60;
                    break;
                case 3:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2 had a paper published in an academic journal.\nHappiness + 30\nFinance + 30";
                    player2Fin += 30;
                    player2Hap += 30;
                    break;
                case 4:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2 nailed their performance and got admited to a summer program in Switzerland.\nHappiness + 60";
                    player2Hap += 60;
                    break;
                case 5:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2 managed to sell their art.\nHappiness + 20\nFinance + 40";
                    player2Hap += 20;
                    player2Fin += 40;
                    break;
                case 6:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2 had the best presentation at CETA day.\nAcademics + 50\nHappiness + 10";
                    player2Aca += 50;
                    player2Hap += 10;
                    break;
                case 7:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 2's student teaching position turned in to a job.\nFinance + 60";
                    player2Fin += 60;
                    break;
            }
        }
        //Stat limits
        if(player2Ste>=100){
            player2Ste=100;
        }
        if(player2Ste<=0){
            player2Ste=0;
        }
        if(player2Aca>=100){
            player2Aca=100;
        }
        if(player2Aca<=0){
            player2Aca=0;
        }
        Academics2.GetComponent<Text>().text = player2Aca.ToString();
        Finance2.GetComponent<Text>().text = player2Fin.ToString();
        Happiness2.GetComponent<Text>().text = player2Hap.ToString();
        Stress2.GetComponent<Text>().text = player2Ste.ToString();
    }

    static void goodEvent3(){   //blue space event for player 3
        int eventNumber = Random.Range(1, 22);
        //aca
        if (eventNumber==1){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 completed a homework assignment.\nAcademics + 8";
            player3Aca+=8;
        }
        if (eventNumber == 2)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 studied for a test.\nAcademics + 10";
            player3Aca += 10;
        }
        if (eventNumber == 3)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 did an extra credit assignment.\nAcademics + 6";
            player3Aca += 6;
        }
        if (eventNumber == 4)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 got the project they were stressed about done quicker then they hoped.\nAcademics + 10\nHappiness + 10";
            player3Aca += 10;
            player3Hap += 10;
        }
        if (eventNumber == 5)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 nailed their presentation.\nAcademics + 6\nStress - 10";
            player3Aca += 6;
            player3Ste -= 10;
        }
        //fin
        if (eventNumber == 6)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3's paycheck came in.\nFinances + 18";
            player3Fin += 18;
        }
        if (eventNumber == 7)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 won a bet.\nFinances + 10%";
            player3Fin = (int)(1.1* player3Fin);
        }
        if (eventNumber == 8)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 found a PDF of their textbook online.\nFinances + 14";
            player3Fin += 14;
        }
        if (eventNumber == 9)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 had a friend swipe them into commons.\nFinances + 10\nHappiness + 12";
            player3Fin += 10;
            player3Hap += 12;
        }
        if (eventNumber == 10)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 found a dollar on the ground.\nFinances + 4\nHappiness + 10";
            player3Fin += 4;
            player3Hap += 10;
        }
        //happy
        if (eventNumber==11){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 is well rested after a good nap.\nHappiness + 14";
            player3Hap+=14;
        }
        if (eventNumber == 12)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 had a good meal at commons.\nHappiness + 10\nStress - 6";
            player3Hap += 10;
            player3Ste -= 6;
        }
        if (eventNumber == 13)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3's favorite TV show got another season.\nHappiness + 16";
            player3Hap += 16;
        }
        if (eventNumber == 14)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 took the break from studying and watched a movie with friends.\nHappiness + 10\nStress - 10";
            player3Hap += 10;
            player3Ste -= 10;
        }
        if (eventNumber == 15)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 went out drinking with friends.\nHappiness + 20";
            player3Hap += 20;
        }
        //stress
        if (eventNumber==16){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3's test was postponed.\nStress - 18";
            player3Ste-=18;
        }
        if (eventNumber == 17)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 started practicing yoga.\nStress - 10";
            player3Ste -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3's date went very well!.\nStress - 8\nHappiness + 10";
            player3Ste -= 8;
            player3Hap += 10;
        }
        if (eventNumber == 19)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3 went home for the weekend.\nStress - 20";
            player3Ste -= 20;
        }
        if (eventNumber == 20)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 3's all-nighter paid off with good grades.\nStress - 10\nAcademics + 10";
            player3Ste -= 10;
            player3Aca += 10;
        }
        //focus
        if (eventNumber==21)
        {
            switch (focusSelect.player3Focus)
            {
                case 1:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3 got a position as a lab instructor.\nAcademics, Finance, and Happiness + 20";
                    player3Aca += 20;
                    player3Fin += 20;
                    player3Hap += 20;
                    break;
                case 2:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3 networked with local business owners and has a summer internship.\nFin + 60";
                    player3Fin += 60;
                    break;
                case 3:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3 had a paper published in an academic journal.\nHappiness + 30\nFinance + 30";
                    player3Fin += 30;
                    player3Hap += 30;
                    break;
                case 4:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3 nailed their performance and got admited to a summer program in Switzerland.\nHappiness + 60";
                    player3Hap += 60;
                    break;
                case 5:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3 managed to sell their art.\nHappiness + 20\nFinance + 40";
                    player3Hap += 20;
                    player3Fin += 40;
                    break;
                case 6:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3 had the best presentation at CETA day.\nAcademics + 50\nHappiness + 10";
                    player3Aca += 50;
                    player3Hap += 10;
                    break;
                case 7:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 3's student teaching position turned in to a job.\nFinance + 60";
                    player3Fin += 60;
                    break;
            }
        }
        //Stat limits
        if(player3Ste>=100){
            player3Ste=100;
        }
        if(player3Ste<=0){
            player3Ste=0;
        }
        if(player3Aca>=100){
            player3Aca=100;
        }
        if(player3Aca<=0){
            player3Aca=0;
        }
        Academics3.GetComponent<Text>().text = player3Aca.ToString();
        Finance3.GetComponent<Text>().text = player3Fin.ToString();
        Happiness3.GetComponent<Text>().text = player3Hap.ToString();
        Stress3.GetComponent<Text>().text = player3Ste.ToString();
    }

    static void goodEvent4(){   //blue space event for player 4
        int eventNumber = Random.Range(1, 22);
        //aca
        if (eventNumber==1){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 completed a homework assignment.\nAcademics + 8";
            player4Aca+=8;
        }
        if (eventNumber == 2)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 studied for a test.\nAcademics + 10";
            player4Aca += 10;
        }
        if (eventNumber == 3)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 did an extra credit assignment.\nAcademics + 6";
            player4Aca += 6;
        }
        if (eventNumber == 4)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 got the project they were stressed about done quicker then they hoped.\nAcademics + 10\nHappiness + 10";
            player4Aca += 10;
            player4Hap += 10;
        }
        if (eventNumber == 5)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 nailed their presentation.\nAcademics + 6\nStress - 10";
            player4Aca += 6;
            player4Ste -= 10;
        }
        //fin
        if (eventNumber == 6)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4's paycheck came in.\nFinances + 18";
            player4Fin += 18;
        }
        if (eventNumber == 7)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 won a bet.\nFinances + 10%";
            player4Fin = (int)(1.1* player4Fin);
        }
        if (eventNumber == 8)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 found a PDF of their textbook online.\nFinances + 14";
            player4Fin += 14;
        }
        if (eventNumber == 9)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 had a friend swipe them into commons.\nFinances + 10\nHappiness + 12";
            player4Fin += 10;
            player4Hap += 12;
        }
        if (eventNumber == 10)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 found a dollar on the ground.\nFinances + 4\nHappiness + 10";
            player4Fin += 4;
            player4Hap += 10;
        }
        //happy
        if (eventNumber==11){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 is well rested after a good nap.\nHappiness + 14";
            player4Hap+=14;
        }
        if (eventNumber == 12)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 had a good meal at commons.\nHappiness + 10\nStress - 6";
            player4Hap += 10;
            player4Ste -= 6;
        }
        if (eventNumber == 13)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4's favorite TV show got another season.\nHappiness + 16";
            player4Hap += 16;
        }
        if (eventNumber == 14)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 took the break from studying and watched a movie with friends.\nHappiness + 10\nStress - 10";
            player4Hap += 10;
            player4Ste -= 10;
        }
        if (eventNumber == 15)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 went out drinking with friends.\nHappiness + 20";
            player4Hap += 20;
        }
        //stress
        if (eventNumber==16){
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4's test was postponed.\nStress - 18";
            player4Ste-=18;
        }
        if (eventNumber == 17)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 started practicing yoga.\nStress - 10";
            player4Ste -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4's date went very well!.\nStress - 8\nHappiness + 10";
            player4Ste -= 8;
            player4Hap += 10;
        }
        if (eventNumber == 19)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4 went home for the weekend.\nStress - 20";
            player4Ste -= 20;
        }
        if (eventNumber == 20)
        {
            eventWindowGood.gameObject.SetActive(true);
            eventTextGood.GetComponent<Text>().text = "Player 4's all-nighter paid off with good grades.\nStress - 10\nAcademics + 10";
            player4Ste -= 10;
            player4Aca += 10;
        }
        //focus
        if (eventNumber==21)
        {
            switch (focusSelect.player4Focus)
            {
                case 1:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4 got a position as a lab instructor.\nAcademics, Finance, and Happiness + 20";
                    player4Aca += 20;
                    player4Fin += 20;
                    player4Hap += 20;
                    break;
                case 2:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4 networked with local business owners and has a summer internship.\nFin + 60";
                    player4Fin += 60;
                    break;
                case 3:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4 had a paper published in an academic journal.\nHappiness + 30\nFinance + 30";
                    player4Fin += 30;
                    player4Hap += 30;
                    break;
                case 4:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4 nailed their performance and got admited to a summer program in Switzerland.\nHappiness + 60";
                    player4Hap += 60;
                    break;
                case 5:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4 managed to sell their art.\nHappiness + 20\nFinance + 40";
                    player4Hap += 20;
                    player4Fin += 40;
                    break;
                case 6:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4 had the best presentation at CETA day.\nAcademics + 50\nHappiness + 10";
                    player4Aca += 50;
                    player4Hap += 10;
                    break;
                case 7:
                    eventWindowGood.gameObject.SetActive(true);
                    eventTextGood.GetComponent<Text>().text = "Academic Focus Event:\nPlayer 4's student teaching position turned in to a job.\nFinance + 60";
                    player4Fin += 60;
                    break;
            }
        }
        //Stat limits
        if(player4Ste>100){
            player4Ste=100;
        }
        if(player4Ste<0){
            player4Ste=0;
        }
        if(player4Aca>100){
            player4Aca=100;
        }
        if(player4Aca<0){
            player4Aca=0;
        }
        Academics4.GetComponent<Text>().text = player4Aca.ToString();
        Finance4.GetComponent<Text>().text = player4Fin.ToString();
        Happiness4.GetComponent<Text>().text = player4Hap.ToString();
        Stress4.GetComponent<Text>().text = player4Ste.ToString();
    }
    static void badEvent1(){   //red space event for player 1
        int eventNumber = Random.Range(1, 21);
        //aca
        if (eventNumber==1){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 missed a homework assignment.\nAcademics - 10";
            player1Aca-=10;
        }
        if (eventNumber == 2)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 slept through an exam.\nAcademics - 20\nStress + 20";
            player1Aca -= 20;
            player1Ste += 20;
        }
        if (eventNumber == 3)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 binged a TV show last night woke up late for class.\nAcademics - 8";
            player1Aca -= 8;
        }
        if (eventNumber == 4)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 has bad professor in their class.\nAcademics - 10\nHappiness - 10";
            player1Aca -= 10;
            player1Hap -= 10;
        }
        if (eventNumber == 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 had a pop quiz they didn't study for.\nAcademics - 14";
            player1Aca -= 14;
        }
        //fin
        if (eventNumber==6){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 had to buy notebooks.\nFinances - 6";
            player1Fin-=6;
        }
        if (eventNumber == 7)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 had to buy a textbook.\nFinances - 20";
            player1Fin -= 20;
        }
        if (eventNumber == 8)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 lost a 10 dollar bill.\nFinances - 10";
            player1Fin -= 10;
        }
        if (eventNumber == 9)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 had to pay for repairs on their car.\nFinances - 14";
            player1Fin -= 14;
        }
        if (eventNumber == 10)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 had to buy groceries.\nFinances - 8";
            player1Fin -= 8;
        }
        //hap
        if (eventNumber==11){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 didn't get much sleep.\nHappiness - 10";
            player1Hap-=10;
        }
        if (eventNumber == 12)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "The front man Player 1's favorite band died.\nHappiness - 20";
            player1Hap -= 20;
        }
        if (eventNumber == 13)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1's friend got in a car accident.\nHappiness - 10\nStress + 14";
            player1Hap -= 10;
            player1Ste += 14;
        }
        if (eventNumber == 14)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 bought a new video game, but it wasn't even good.\nHappiness - 10 Finances - 14";
            player1Hap -= 10;
            player1Fin -= 14;
        }
        if (eventNumber == 15)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 stubbed their toe.\nHappiness - 5";
            player1Hap -= 5;
        }
        //stre
        if (eventNumber==16)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 was assigned a project.\nStress + 16";
            player1Ste+=14;
        }
        if (eventNumber == 17)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 wasn't able to sleep after watching a horror movie.\nStress + 12\nHappiness - 10";
            player1Ste += 12;
            player1Hap -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 got made fun of for their hair cut.\nStress + 8\nHappiness - 14";
            player1Ste += 8;
            player1Hap -= 14;
        }
        if (eventNumber == 19)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 had their workload increased.\nStress * 1.2";
            player1Ste = (int)(1.2* player1Ste);
        }
        if (eventNumber == 20)// && player1Ste >= 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 1 hopes no one notices the stain on their shirt.\nStress + 6";
            player1Ste += 6;
        }
        //Stat limits
        if(player1Ste>=100){
            player1Ste=100;
        }
        if(player1Ste<=0){
            player1Ste=0;
        }
        if(player1Aca>=100){
            player1Aca=100;
        }
        if(player1Aca<=0){
            player1Aca=0;
        }
        Academics1.GetComponent<Text>().text = player1Aca.ToString();
        Finance1.GetComponent<Text>().text = player1Fin.ToString();
        Happiness1.GetComponent<Text>().text = player1Hap.ToString();
        Stress1.GetComponent<Text>().text = player1Ste.ToString();
    }
    static void badEvent2(){   //red space event for player 2
        int eventNumber = Random.Range(1, 21);
        //aca
        if (eventNumber==1){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 missed a homework assignment.\nAcademics - 10";
            player2Aca-=10;
        }
        if (eventNumber == 2)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 slept through an exam.\nAcademics - 20\nStress + 20";
            player2Aca -= 20;
            player2Ste += 20;
        }
        if (eventNumber == 3)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 binged a TV show last night woke up late for class.\nAcademics - 8";
            player2Aca -= 8;
        }
        if (eventNumber == 4)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 has bad professor in their class.\nAcademics - 10\nHappiness - 10";
            player2Aca -= 10;
            player2Hap -= 10;
        }
        if (eventNumber == 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 had a pop quiz they didn't study for.\nAcademics - 14";
            player2Aca -= 14;
        }
        //fin
        if (eventNumber==6){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 had to buy notebooks.\nFinances - 6";
            player2Fin-=6;
        }
        if (eventNumber == 7)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 had to buy a textbook.\nFinances - 20";
            player2Fin -= 20;
        }
        if (eventNumber == 8)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 lost a 10 dollar bill.\nFinances - 10";
            player2Fin -= 10;
        }
        if (eventNumber == 9)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 had to pay for repairs on their car.\nFinances - 14";
            player2Fin -= 14;
        }
        if (eventNumber == 10)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 had to buy groceries.\nFinances - 8";
            player2Fin -= 8;
        }
        //hap
        if (eventNumber==11){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 didn't get much sleep.\nHappiness - 10";
            player2Hap-=10;
        }
        if (eventNumber == 12)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "The front man Player 2's favorite band died.\nHappiness - 20";
            player2Hap -= 20;
        }
        if (eventNumber == 13)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2's friend got in a car accident.\nHappiness - 10\nStress + 14";
            player2Hap -= 10;
            player2Ste += 14;
        }
        if (eventNumber == 14)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 bought a new video game, but it wasn't even good.\nHappiness - 10 Finances - 14";
            player2Hap -= 10;
            player2Fin -= 14;
        }
        if (eventNumber == 15)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 stubbed their toe.\nHappiness - 5";
            player2Hap -= 5;
        }
        //stre
        if (eventNumber==16)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 was assigned a project.\nStress + 16";
            player2Ste+=14;
        }
        if (eventNumber == 17)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 wasn't able to sleep after watching a horror movie.\nStress + 12\nHappiness - 10";
            player2Ste += 12;
            player2Hap -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 got made fun of for their hair cut.\nStress + 8\nHappiness - 14";
            player2Ste += 8;
            player2Hap -= 14;
        }
        if (eventNumber == 19)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 had their workload increased.\nStress * 1.2";
            player2Ste = (int)(1.2* player2Ste);
        }
        if (eventNumber == 20)// && player2Ste >= 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 2 hopes no one notices the stain on their shirt.\nStress + 6";
            player2Ste += 6;
        }
        //Stat limits
        if(player2Ste>=100){
            player2Ste=100;
        }
        if(player2Ste<=0){
            player2Ste=0;
        }
        if(player2Aca>=100){
            player2Aca=100;
        }
        if(player2Aca<=0){
            player2Aca=0;
        }
        Academics2.GetComponent<Text>().text = player2Aca.ToString();
        Finance2.GetComponent<Text>().text = player2Fin.ToString();
        Happiness2.GetComponent<Text>().text = player2Hap.ToString();
        Stress2.GetComponent<Text>().text = player2Ste.ToString();
    }
    static void badEvent3(){   //red space event for player 3
        int eventNumber = Random.Range(1, 21);
        //aca
        if (eventNumber==1){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 missed a homework assignment.\nAcademics - 10";
            player3Aca-=10;
        }
        if (eventNumber == 2)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 slept through an exam.\nAcademics - 20\nStress + 20";
            player3Aca -= 20;
            player3Ste += 20;
        }
        if (eventNumber == 3)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 binged a TV show last night woke up late for class.\nAcademics - 8";
            player3Aca -= 8;
        }
        if (eventNumber == 4)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 has bad professor in their class.\nAcademics - 10\nHappiness - 10";
            player3Aca -= 10;
            player3Hap -= 10;
        }
        if (eventNumber == 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 had a pop quiz they didn't study for.\nAcademics - 14";
            player3Aca -= 14;
        }
        //fin
        if (eventNumber==6){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 had to buy notebooks.\nFinances - 6";
            player3Fin-=6;
        }
        if (eventNumber == 7)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 had to buy a textbook.\nFinances - 20";
            player3Fin -= 20;
        }
        if (eventNumber == 8)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 lost a 10 dollar bill.\nFinances - 10";
            player3Fin -= 10;
        }
        if (eventNumber == 9)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 had to pay for repairs on their car.\nFinances - 14";
            player3Fin -= 14;
        }
        if (eventNumber == 10)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 had to buy groceries.\nFinances - 8";
            player3Fin -= 8;
        }
        //hap
        if (eventNumber==11){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 didn't get much sleep.\nHappiness - 10";
            player3Hap-=10;
        }
        if (eventNumber == 12)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "The front man Player 3's favorite band died.\nHappiness - 20";
            player3Hap -= 20;
        }
        if (eventNumber == 13)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3's friend got in a car accident.\nHappiness - 10\nStress + 14";
            player3Hap -= 10;
            player3Ste += 14;
        }
        if (eventNumber == 14)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 bought a new video game, but it wasn't even good.\nHappiness - 10 Finances - 14";
            player3Hap -= 10;
            player3Fin -= 14;
        }
        if (eventNumber == 15)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 stubbed their toe.\nHappiness - 5";
            player3Hap -= 5;
        }
        //stre
        if (eventNumber==16)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 was assigned a project.\nStress + 16";
            player3Ste+=14;
        }
        if (eventNumber == 17)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 wasn't able to sleep after watching a horror movie.\nStress + 12\nHappiness - 10";
            player3Ste += 12;
            player3Hap -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 got made fun of for their hair cut.\nStress + 8\nHappiness - 14";
            player3Ste += 8;
            player3Hap -= 14;
        }
        if (eventNumber == 19)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 had their workload increased.\nStress * 1.2";
            player3Ste = (int)(1.2* player3Ste);
        }
        if (eventNumber == 20)// && player3Ste >= 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 3 hopes no one notices the stain on their shirt.\nStress + 6";
            player3Ste += 6;
        }
        //Stat limits
        if(player3Ste>=100){
            player3Ste=100;
        }
        if(player3Ste<=0){
            player3Ste=0;
        }
        if(player3Aca>=100){
            player3Aca=100;
        }
        if(player3Aca<=0){
            player3Aca=0;
        }
        Academics3.GetComponent<Text>().text = player3Aca.ToString();
        Finance3.GetComponent<Text>().text = player3Fin.ToString();
        Happiness3.GetComponent<Text>().text = player3Hap.ToString();
        Stress3.GetComponent<Text>().text = player3Ste.ToString();
    }
    static void badEvent4(){   //red space event for player 4
        int eventNumber = Random.Range(1, 21);
        //aca
        if (eventNumber==1){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 missed a homework assignment.\nAcademics - 10";
            player4Aca-=10;
        }
        if (eventNumber == 2)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 slept through an exam.\nAcademics - 20\nStress + 20";
            player4Aca -= 20;
            player4Ste += 20;
        }
        if (eventNumber == 3)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 binged a TV show last night woke up late for class.\nAcademics - 8";
            player4Aca -= 8;
        }
        if (eventNumber == 4)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 has bad professor in their class.\nAcademics - 10\nHappiness - 10";
            player4Aca -= 10;
            player4Hap -= 10;
        }
        if (eventNumber == 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 had a pop quiz they didn't study for.\nAcademics - 14";
            player4Aca -= 14;
        }
        //fin
        if (eventNumber==6){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 had to buy notebooks.\nFinances - 6";
            player4Fin-=6;
        }
        if (eventNumber == 7)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 had to buy a textbook.\nFinances - 20";
            player4Fin -= 20;
        }
        if (eventNumber == 8)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 lost a 10 dollar bill.\nFinances - 10";
            player4Fin -= 10;
        }
        if (eventNumber == 9)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 had to pay for repairs on their car.\nFinances - 14";
            player4Fin -= 14;
        }
        if (eventNumber == 10)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 had to buy groceries.\nFinances - 8";
            player4Fin -= 8;
        }
        //hap
        if (eventNumber==11){
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 didn't get much sleep.\nHappiness - 10";
            player4Hap-=10;
        }
        if (eventNumber == 12)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "The front man Player 4's favorite band died.\nHappiness - 20";
            player4Hap -= 20;
        }
        if (eventNumber == 13)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4's friend got in a car accident.\nHappiness - 10\nStress + 14";
            player4Hap -= 10;
            player4Ste += 14;
        }
        if (eventNumber == 14)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 bought a new video game, but it wasn't even good.\nHappiness - 10 Finances - 14";
            player4Hap -= 10;
            player4Fin -= 14;
        }
        if (eventNumber == 15)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 stubbed their toe.\nHappiness - 5";
            player4Hap -= 5;
        }
        //stre
        if (eventNumber==16)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 was assigned a project.\nStress + 16";
            player4Ste+=14;
        }
        if (eventNumber == 17)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 wasn't able to sleep after watching a horror movie.\nStress + 12\nHappiness - 10";
            player4Ste += 12;
            player4Hap -= 10;
        }
        if (eventNumber == 18)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 got made fun of for their hair cut.\nStress + 8\nHappiness - 14";
            player4Ste += 8;
            player4Hap -= 14;
        }
        if (eventNumber == 19)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 had their workload increased.\nStress * 1.2";
            player4Ste = (int)(1.2* player4Ste);
        }
        if (eventNumber == 20)// && player4Ste >= 5)
        {
            eventWindowBad.gameObject.SetActive(true);
            eventTextBad.GetComponent<Text>().text = "Player 4 hopes no one notices the stain on their shirt.\nStress + 6";
            player4Ste += 6;
        }
        //Stat limits
        if(player4Ste>=100){
            player4Ste=100;
        }
        if(player4Ste<=0){
            player4Ste=0;
        }
        if(player4Aca>=100){
            player4Aca=100;
        }
        if(player4Aca<=0){
            player4Aca=0;
        }
        Academics4.GetComponent<Text>().text = player4Aca.ToString();
        Finance4.GetComponent<Text>().text = player4Fin.ToString();
        Happiness4.GetComponent<Text>().text = player4Hap.ToString();
        Stress4.GetComponent<Text>().text = player4Ste.ToString();
    }

    static void gcEvent1(){
        if(player1Aca<=15||player1Hap<=15||player1Ste>=85){
            eventWindowGC.gameObject.SetActive(true);
            eventTextGC.GetComponent<Text>().text = "Player 1, you appear to be having a hard time. Would you like to attend CAPS?\n(Counselling and Psychological Services)";
        }
    }
    static void gcEvent2(){
        if(player2Aca<=15||player2Hap<=15||player2Ste>=85){
            eventWindowGC.gameObject.SetActive(true);
            eventTextGC.GetComponent<Text>().text = "Player 2, you appear to be having a hard time. Would you like to attend CAPS?\n(Counselling and Psychological Services)";
        }
    }
    static void gcEvent3(){
        if(player3Aca<=15||player3Hap<=15||player3Ste>=85){
            eventWindowGC.gameObject.SetActive(true);
            eventTextGC.GetComponent<Text>().text = "Player 3, you appear to be having a hard time. Would you like to attend CAPS?\n(Counselling and Psychological Services)";
        }
    }
    static void gcEvent4(){
        if(player4Aca<=15||player4Hap<=15||player4Ste>=85){
            eventWindowGC.gameObject.SetActive(true);
            eventTextGC.GetComponent<Text>().text = "Player 4, you appear to be having a hard time. Would you like to attend CAPS?\n(Counselling and Psychological Services)";
        }
    }
    public void gcEventConfirm(){
        eventWindowGC.gameObject.SetActive(false);
        eventWindowGood.gameObject.SetActive(true);
        eventTextGood.GetComponent<Text>().text = "Academics + 30\nHappiness + 30\nStress - 20";
        if(Die.turn==2){ //Increase stats for player 1
            player1Aca+=30;
            player1Hap+=30;
            player1Ste-=20;
            if(player1Ste>=100){
                player1Ste=100;
            }
            if(player1Ste<=0){
                player1Ste=0;
            }
            if(player1Aca>=100){
                player1Aca=100;
            }
            if(player1Aca<=0){
                player1Aca=0;
            }
            Academics1.GetComponent<Text>().text = player1Aca.ToString();
            Happiness1.GetComponent<Text>().text = player1Hap.ToString();
            Stress1.GetComponent<Text>().text = player1Ste.ToString();
        }
        else if(Die.turn==3){
            player2Aca+=30;
            player2Hap+=30;
            player2Ste-=20;
            if(player2Ste>=100){
                player2Ste=100;
            }
            if(player2Ste<=0){
                player2Ste=0;
            }
            if(player2Aca>=100){
                player2Aca=100;
            }
            if(player2Aca<=0){
                player2Aca=0;
            }
            Academics2.GetComponent<Text>().text = player2Aca.ToString();
            Happiness2.GetComponent<Text>().text = player2Hap.ToString();
            Stress2.GetComponent<Text>().text = player2Ste.ToString();
        }
        else if(Die.turn==4){
            player3Aca+=30;
            player3Hap+=30;
            player3Ste-=20;
            if(player3Ste>=100){
                player3Ste=100;
            }
            if(player3Ste<=0){
                player3Ste=0;
            }
            if(player3Aca>=100){
                player3Aca=100;
            }
            if(player3Aca<=0){
                player3Aca=0;
            }
            Academics3.GetComponent<Text>().text = player3Aca.ToString();
            Happiness3.GetComponent<Text>().text = player3Hap.ToString();
            Stress3.GetComponent<Text>().text = player3Ste.ToString();
        }
        else if(Die.turn==5){
            player4Aca+=30;
            player4Hap+=30;
            player4Ste-=20;
            if(player4Ste>=100){
                player4Ste=100;
            }
            if(player4Ste<=0){
                player4Ste=0;
            }
            if(player4Aca>=100){
                player4Aca=100;
            }
            if(player4Aca<=0){
                player4Aca=0;
            }
            Academics4.GetComponent<Text>().text = player4Aca.ToString();
            Happiness4.GetComponent<Text>().text = player4Hap.ToString();
            Stress4.GetComponent<Text>().text = player4Ste.ToString();
        }
        
    }

    public IEnumerator wait()
    {
        yield return new WaitForSeconds(500f); //delay game between turns
    }

    public static void MovePlayer(int playerMove)
    {
        switch (playerMove)
        {
            case 1:
            player1.GetComponent<Movement>().moveAllowed = true;
            break;
            case 2:
            player2.GetComponent<Movement>().moveAllowed = true;
            break;
            case 3:
            player3.GetComponent<Movement>().moveAllowed = true;
            break;
            case 4:
            player4.GetComponent<Movement>().moveAllowed = true;
            break;
        }
    }
}
