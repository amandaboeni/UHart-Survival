﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pauseScreen : MonoBehaviour {

	private static GameObject PauseScreen;
	// Use this for initialization
	void Start () {
		PauseScreen = GameObject.Find("PauseScreen");
		PauseScreen.gameObject.SetActive(false);
		
	}
	
	// Update is called once per frame
	void Update () {
		//PauseScreen = GameObject.Find("PauseScreen");
		if (Input.GetKey("escape"))
        {
			//Debug.Log("YOU PRESSED ESCAPE DUMMY!");
			PauseScreen.gameObject.SetActive(true);
		}
	}
	public void resumeGame()
    {
        PauseScreen = GameObject.Find("PauseScreen");
        if(PauseScreen.activeSelf){
            PauseScreen.gameObject.SetActive(false);
        }
    }
	public void exitGame()
	{
		Application.Quit();
	}
}
